namespace Accelerometer
{
	[global::Foundation.Register ("AppDelegate")]
	public partial class AppDelegate
	{
	}
}
