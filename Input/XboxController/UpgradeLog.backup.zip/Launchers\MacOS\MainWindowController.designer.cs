namespace XBoxController
{
	[global::Foundation.Register ("MainWindowController")]
	public partial class MainWindowController
	{
	}
}
