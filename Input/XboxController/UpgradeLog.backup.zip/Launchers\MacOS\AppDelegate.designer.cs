namespace XBoxController
{
	[global::Foundation.Register ("AppDelegate")]
	public partial class AppDelegate
	{
	}
}
