namespace NormalMap
{
	[global::Foundation.Register ("MainWindowController")]
	public partial class MainWindowController
	{
	}
}
