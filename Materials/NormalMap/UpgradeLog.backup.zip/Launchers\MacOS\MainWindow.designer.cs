namespace NormalMap
{
	[global::Foundation.Register ("MainWindow")]
	public partial class MainWindow
	{
	}
}
