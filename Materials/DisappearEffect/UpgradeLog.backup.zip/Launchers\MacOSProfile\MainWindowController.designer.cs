namespace DisappearEffect
{
	[global::Foundation.Register ("MainWindowController")]
	public partial class MainWindowController
	{
	}
}
