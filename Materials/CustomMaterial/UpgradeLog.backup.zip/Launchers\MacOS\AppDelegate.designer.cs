namespace CustomMaterial
{
	[global::Foundation.Register ("AppDelegate")]
	public partial class AppDelegate
	{
	}
}
